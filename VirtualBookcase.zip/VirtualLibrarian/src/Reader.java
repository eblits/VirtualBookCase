import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

public class Reader {

        // Read file method
        public static ArrayList<Book> readFile() {

        // Set up our variables
        String fileName = "Bookcase.txt";
        String line;
        // Create an empty arraylist
        ArrayList<Book> bookOnFile = new ArrayList<>();

        // Read file
        try {
            BufferedReader input = new BufferedReader(new FileReader(fileName));
            if (!input.ready()){
                throw new IOException();
            }
            // While there is a line to be read
            while ((line = input.readLine()) != null) {
                // Separate our file lines by our delimiter '||' and add those serrated strings to an array
                String[] data = line.split(Pattern.quote("||"));
                Book temp = new Book(data);
                bookOnFile.add(temp);
            }
            input.close();
        } catch (IOException e){

        }
        // Return our array
        return bookOnFile;
    }
}
